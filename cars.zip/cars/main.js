var dialog = document.querySelector('dialog')
document.querySelector('.section__button').onclick = function () {
  dialog.showModal()
}
document.querySelector('.close').onclick = function () {
  dialog.close() 
}

