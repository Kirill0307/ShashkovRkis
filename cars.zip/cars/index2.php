<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?
    family=Bebas+Neue&family=Inter:wght@400;700&display=swap" 
    rel="stylesheet">
    <link type="image/x-icon" rel="shortcut icon" href="images/ico.ico">
    <link rel="stylesheet" href="css/normalize.css">
    <link rel="stylesheet" href="css/style.css">
    <script src="js/main2.js" defer></script>
    <title>Apple</title>
</head>
<body>
    <header class="header">
        <div class="container">
                      <div class="dropdown"> 
                <div class="dropdown_between"> 
                    <a href="index.php" class="logo">
                        <img src="images/logo.svg" alt="лого" height="80" class="logo__img">
                    </a>
                </div> 
                <div class="dropdown_between"> 
                    <a href="#" class="korzina">
                        <img src="images/korzina.png" alt="поиск" class="korzina__img">
                    </a> 
                </div> 
                <div class="dropdown_between"> 
                    <button class="dropbtn">Меню</button> 
                    <div class="dropdown-content"> 
                      <a href="index6.html" class="border_nav">Вход</a> 
                      <a href="index2.html" class="border_nav">Каталог</a> 
                      <a href="index5.html" class="border_nav">Корзина</a> 
                    </div> 
                </div>
            </div>
            <nav class="nav">
                <ul class="menu">
                    <li class="menu__item">
                        <a class="menu__link" href="index6.html">Личный кабинет</a>
                    </li>
                    <li class="menu__item">
                        <a class="menu__link" href="index2.html">Каталог</a>
                    </li>
                    <li class="menu__item">
                        <a class="menu__link" href="index5.html">Корзина</a>
                    </li>
                </ul>
                <a href="index.php" class="logo">
                    <img src="images/logo.svg" alt="лого" height="80" class="logo__img">
                </a>
                <a href="tel:+7 913 813 6329" class="phone">+7 913-813-63-29</a>
            </nav>
        </div>
    </header>
    <div class="search_res"> 
                        <form action="index2.php" method="get">
                            <input class="input_form" type="search" name="search_text">
                            <input class="search_button" type="submit" name="submit" value="Найти">
                        </form>
                       
                    </div>
    <?php
			$mysqli = new mysqli("localhost","root","","sait",3306);
            if (isset($_GET['submit']) && isset($_GET['search_text'])){
                            $search_res=$_GET['search_text'];
                            $query = 'select * from katalog where id_telefon like "%'.$search_res.'%" or id_kategoria like "%'.$search_res.'%"';
                            $result = mysqli_query($mysqli, $query);
                            echo '<div class="box-serv"><h2></h2><br>';
                            while($n = mysqli_fetch_assoc($result)){
                                echo '<div class="teh_serv"><p class="teh_text">'.$n['id_telefon'].'<p class="phone__list"><img class="phone__list" src="images/'.$n['id_img'].'"><p class="phone__list">'.'</p><p class="phone__list">'.$n['id_price'];
                            }
                            echo '</div>';
                        }
                        else{
                         
                            //$query = 'select * from katalog';
                            //$result = mysqli_query($mysqli, $query);
                            //echo '<div class="box-serv"><h2></h2><br>';
                            //while($n = mysqli_fetch_assoc($result)){
                            //    echo '<div class="teh-serv"><img class="teh-img" src="img/'.$n['id_telefon'].'"><p class="teh-text">'.$n['id_kategoria'].'</p><p class="teh-text">'.$n['id_price'].'</p><button class="serv-button">Выбрать</button></div>';
                            //}
                            //echo '</div>';	
                        }
                      
                        ?>
    
    <main class="main">
      <section class="katagog">
          <div class="container">       
              <div class="katalog__title">
                  <h1 class="katalog__titlee">
                      Каталог
                  </h1>
              </div> 
          </div>
      </section>
      <section class="phone__page2">
          <div class="container">
    <?php
    $a=mysqli_connect('localhost', 'root', '', 'sait') or die('connection error'); //устанавливаем подключение к БД
    $q="SELECT * FROM katalog where id_kategoria='iphone'"; //создаем запрос на выборку данных
    $r=mysqli_query($a, $q) or die('error:'.mysqli_error()); //выполняем запрос, сохраняя при этом результат в переменную $r
    echo '<h2 class="color__title">IPHONE</h2>
    <ul class="phone__list">';
    while($n = mysqli_fetch_array($r)){   //в цикле перебираем все записи в массиве $r, при этом каждая запись обозначена переменной $n
        //здесь в теле цикла формируем div блоки для каждой карточки: 
        // По мере необходимости вставляем полученные значения из БД, пользуясь переменными вида: $n['photo'], $n['name'] и др.
        echo '<li class="phone__item">
          <img class="img__iphone" src="images/'.$n["id_img"].'" alt="iphone">
          <h3>'.$n["id_telefon"].'</h3>
          <p>'.$n["id_price"].'&#8381;</p>
          <button class="phone__btn" data-modal="myModal1">'.$n["id_button"].'</button>
          <div id="myModal1" class="modal">
            <div class="modal-content">
              <div class="modal-header">
                  <span class="close" data-modal="myModal1">&times;</span>
              </div>
              <div class="modal-body">
                  <div class="modal__title">'.$n["id_telefon"].'</div><br>
                  <b>Цвет: </b> '.$n["id_color"].'<br>
                  <b>Количество памяти: </b>'.$n["id_storage"].'<br>
                  <b>Связь: </b>'.$n["id_connection"].'<br>
                  <b>Диагональ:</b>'.$n["id_diagonal"].'<br>
                  <b>Тип дисплея:</b>'.$n["id_display"].'<br>
                  <b>Основная камера:</b> '.$n["id_main_camera"].'<br>
                  <b>Фронтальная камера:</b> '.$n["id_front_camera"].'<br>
                  <b>Страна происхождения:</b> '.$n["id_country"].'<br>
                  <b>Процессор:</b> '.$n["id_processor"].'<br>
                  <b>Емкость аккумулятора:</b> '.$n["id_battery"].'<br>
                  <button class="add_korzina" href="#">Добавить</button>
              </div>
            </div>
          </div>
      </li>';
      '<li class="phone__item">
          <img class="img__iphone" src="images/'.$n["id_img"].'" alt="iphone">
          <h3>'.$n["id_telefon"].'</h3>
          <p>'.$n["id_price"].'&#8381;</p>
          <button class="phone__btn" data-modal="myModal1">'.$n["id_button"].'</button>
          <div id="myModal1" class="modal">
            <div class="modal-content">
              <div class="modal-header">
                  <span class="close" data-modal="myModal1">&times;</span>
              </div>
              <div class="modal-body">
              <div class="modal__title">'.$n["id_telefon"].'</div><br>
              <b>Цвет: </b> '.$n["id_color"].'<br>
              <b>Количество памяти: </b>'.$n["id_storage"].'<br>
              <b>Связь: </b>'.$n["id_connection"].'<br>
              <b>Диагональ:</b>'.$n["id_diagonal"].'<br>
              <b>Тип дисплея:</b>'.$n["id_display"].'<br>
              <b>Основная камера:</b> '.$n["id_main_camera"].'<br>
              <b>Фронтальная камера:</b> '.$n["id_front_camera"].'<br>
              <b>Страна происхождения:</b> '.$n["id_country"].'<br>
              <b>Процессор:</b> '.$n["id_processor"].'<br>
              <b>Емкость аккумулятора:</b> '.$n["id_battery"].'<br>
              <button class="add_korzina" href="#">Добавить</button>
              </div>
            </div>
          </div>
      </li>';
            '<li class="phone__item">
          <img class="img__iphone" src="images/'.$n["id_img"].'" alt="iphone">
          <h3>'.$n["id_telefon"].'</h3>
          <p>'.$n["id_price"].'&#8381;</p>
          <button class="phone__btn" data-modal="myModal1">'.$n["id_button"].'</button>
          <div id="myModal1" class="modal">
            <div class="modal-content">
              <div class="modal-header">
                  <span class="close" data-modal="myModal1">&times;</span>
              </div>
              <div class="modal-body">
              <div class="modal__title">'.$n["id_telefon"].'</div><br>
              <b>Цвет: </b> '.$n["id_color"].'<br>
              <b>Количество памяти: </b>'.$n["id_storage"].'<br>
              <b>Связь: </b>'.$n["id_connection"].'<br>
              <b>Диагональ:</b>'.$n["id_diagonal"].'<br>
              <b>Тип дисплея:</b>'.$n["id_display"].'<br>
              <b>Основная камера:</b> '.$n["id_main_camera"].'<br>
              <b>Фронтальная камера:</b> '.$n["id_front_camera"].'<br>
              <b>Страна происхождения:</b> '.$n["id_country"].'<br>
              <b>Процессор:</b> '.$n["id_processor"].'<br>
              <b>Емкость аккумулятора:</b> '.$n["id_battery"].'<br>
              <button class="add_korzina" href="#">Добавить</button>
              </div>
            </div>
          </div>
      </li>';
            '<li class="phone__item">
          <img class="img__iphone" src="images/'.$n["id_img"].'" alt="iphone">
          <h3>'.$n["id_telefon"].'</h3>
          <p>'.$n["id_price"].'&#8381;</p>
          <button class="phone__btn" data-modal="myModal1">'.$n["id_button"].'</button>
          <div id="myModal1" class="modal">
            <div class="modal-content">
              <div class="modal-header">
                  <span class="close" data-modal="myModal1">&times;</span>
              </div>
              <div class="modal-body">
              <div class="modal__title">'.$n["id_telefon"].'</div><br>
              <b>Цвет: </b> '.$n["id_color"].'<br>
              <b>Количество памяти: </b>'.$n["id_storage"].'<br>
              <b>Связь: </b>'.$n["id_connection"].'<br>
              <b>Диагональ:</b>'.$n["id_diagonal"].'<br>
              <b>Тип дисплея:</b>'.$n["id_display"].'<br>
              <b>Основная камера:</b> '.$n["id_main_camera"].'<br>
              <b>Фронтальная камера:</b> '.$n["id_front_camera"].'<br>
              <b>Страна происхождения:</b> '.$n["id_country"].'<br>
              <b>Процессор:</b> '.$n["id_processor"].'<br>
              <b>Емкость аккумулятора:</b> '.$n["id_battery"].'<br>
              <button class="add_korzina" href="#">Добавить</button>
              </div>
            </div>
          </div>
      </li>';
            '<li class="phone__item">
          <img class="img__iphone" src="images/'.$n["id_img"].'" alt="iphone">
          <h3>'.$n["id_telefon"].'</h3>
          <p>'.$n["id_price"].'&#8381;</p>
          <button class="phone__btn" data-modal="myModal1">'.$n["id_button"].'</button>
          <div id="myModal1" class="modal">
            <div class="modal-content">
              <div class="modal-header">
                  <span class="close" data-modal="myModal1">&times;</span>
              </div>
              <div class="modal-body">
              <div class="modal__title">'.$n["id_telefon"].'</div><br>
              <b>Цвет: </b> '.$n["id_color"].'<br>
              <b>Количество памяти: </b>'.$n["id_storage"].'<br>
              <b>Связь: </b>'.$n["id_connection"].'<br>
              <b>Диагональ:</b>'.$n["id_diagonal"].'<br>
              <b>Тип дисплея:</b>'.$n["id_display"].'<br>
              <b>Основная камера:</b> '.$n["id_main_camera"].'<br>
              <b>Фронтальная камера:</b> '.$n["id_front_camera"].'<br>
              <b>Страна происхождения:</b> '.$n["id_country"].'<br>
              <b>Процессор:</b> '.$n["id_processor"].'<br>
              <b>Емкость аккумулятора:</b> '.$n["id_battery"].'<br>
              <button class="add_korzina" href="#">Добавить</button>
              </div>
            </div>
          </div>
      </li>';
            '<li class="phone__item">
          <img class="img__iphone" src="images/'.$n["id_img"].'" alt="iphone">
          <h3>'.$n["id_telefon"].'</h3>
          <p>'.$n["id_price"].'&#8381;</p>
          <button class="phone__btn" data-modal="myModal1">'.$n["id_button"].'</button>
          <div id="myModal1" class="modal">
            <div class="modal-content">
              <div class="modal-header">
                  <span class="close" data-modal="myModal1">&times;</span>
              </div>
              <div class="modal-body">
              <div class="modal__title">'.$n["id_telefon"].'</div><br>
              <b>Цвет: </b> '.$n["id_color"].'<br>
              <b>Количество памяти: </b>'.$n["id_storage"].'<br>
              <b>Связь: </b>'.$n["id_connection"].'<br>
              <b>Диагональ:</b>'.$n["id_diagonal"].'<br>
              <b>Тип дисплея:</b>'.$n["id_display"].'<br>
              <b>Основная камера:</b> '.$n["id_main_camera"].'<br>
              <b>Фронтальная камера:</b> '.$n["id_front_camera"].'<br>
              <b>Страна происхождения:</b> '.$n["id_country"].'<br>
              <b>Процессор:</b> '.$n["id_processor"].'<br>
              <b>Емкость аккумулятора:</b> '.$n["id_battery"].'<br>
              <button class="add_korzina" href="#">Добавить</button>
              </div>
            </div>
          </div>
      </li>';
            '<li class="phone__item">
          <img class="img__iphone" src="images/'.$n["id_img"].'" alt="iphone">
          <h3>'.$n["id_telefon"].'</h3>
          <p>'.$n["id_price"].'&#8381;</p>
          <button class="phone__btn" data-modal="myModal1">'.$n["id_button"].'</button>
          <div id="myModal1" class="modal">
            <div class="modal-content">
              <div class="modal-header">
                  <span class="close" data-modal="myModal1">&times;</span>
              </div>
              <div class="modal-body">
              <div class="modal__title">'.$n["id_telefon"].'</div><br>
              <b>Цвет: </b> '.$n["id_color"].'<br>
              <b>Количество памяти: </b>'.$n["id_storage"].'<br>
              <b>Связь: </b>'.$n["id_connection"].'<br>
              <b>Диагональ:</b>'.$n["id_diagonal"].'<br>
              <b>Тип дисплея:</b>'.$n["id_display"].'<br>
              <b>Основная камера:</b> '.$n["id_main_camera"].'<br>
              <b>Фронтальная камера:</b> '.$n["id_front_camera"].'<br>
              <b>Страна происхождения:</b> '.$n["id_country"].'<br>
              <b>Процессор:</b> '.$n["id_processor"].'<br>
              <b>Емкость аккумулятора:</b> '.$n["id_battery"].'<br>
              <button class="add_korzina" href="#">Добавить</button>
              </div>
            </div>
          </div>
      </li>';
            '<li class="phone__item">
          <img class="img__iphone" src="images/'.$n["id_img"].'" alt="iphone">
          <h3>'.$n["id_telefon"].'</h3>
          <p>'.$n["id_price"].'&#8381;</p>
          <button class="phone__btn" data-modal="myModal1">'.$n["id_button"].'</button>
          <div id="myModal1" class="modal">
            <div class="modal-content">
              <div class="modal-header">
                  <span class="close" data-modal="myModal1">&times;</span>
              </div>
              <div class="modal-body">
              <div class="modal__title">'.$n["id_telefon"].'</div><br>
              <b>Цвет: </b> '.$n["id_color"].'<br>
              <b>Количество памяти: </b>'.$n["id_storage"].'<br>
              <b>Связь: </b>'.$n["id_connection"].'<br>
              <b>Диагональ:</b>'.$n["id_diagonal"].'<br>
              <b>Тип дисплея:</b>'.$n["id_display"].'<br>
              <b>Основная камера:</b> '.$n["id_main_camera"].'<br>
              <b>Фронтальная камера:</b> '.$n["id_front_camera"].'<br>
              <b>Страна происхождения:</b> '.$n["id_country"].'<br>
              <b>Процессор:</b> '.$n["id_processor"].'<br>
              <b>Емкость аккумулятора:</b> '.$n["id_battery"].'<br>
              <button class="add_korzina" href="#">Добавить</button>
              </div>
            </div>
          </div>
      </li>';
            '<li class="phone__item">
          <img class="img__iphone" src="images/'.$n["id_img"].'" alt="iphone">
          <h3>'.$n["id_telefon"].'</h3>
          <p>'.$n["id_price"].'&#8381;</p>
          <button class="phone__btn" data-modal="myModal1">'.$n["id_button"].'</button>
          <div id="myModal1" class="modal">
            <div class="modal-content">
              <div class="modal-header">
                  <span class="close" data-modal="myModal1">&times;</span>
              </div>
              <div class="modal-body">
              <div class="modal__title">'.$n["id_telefon"].'</div><br>
              <b>Цвет: </b> '.$n["id_color"].'<br>
              <b>Количество памяти: </b>'.$n["id_storage"].'<br>
              <b>Связь: </b>'.$n["id_connection"].'<br>
              <b>Диагональ:</b>'.$n["id_diagonal"].'<br>
              <b>Тип дисплея:</b>'.$n["id_display"].'<br>
              <b>Основная камера:</b> '.$n["id_main_camera"].'<br>
              <b>Фронтальная камера:</b> '.$n["id_front_camera"].'<br>
              <b>Страна происхождения:</b> '.$n["id_country"].'<br>
              <b>Процессор:</b> '.$n["id_processor"].'<br>
              <b>Емкость аккумулятора:</b> '.$n["id_battery"].'<br>
              <button class="add_korzina" href="#">Добавить</button>
              </div>
            </div>
          </div>
      </li>';
      
     }
  echo '</div>'; //закрываем div внешнего блока  
  mysqli_close($a);  //закрываем подключение с базой
  ?>
                </ul>                
            </div>     
        </section>
        <section class="phone__page2">
            <div class="container">

<?php
    $a=mysqli_connect('localhost', 'root', '', 'sait') or die('connection error'); //устанавливаем подключение к БД
    $q="SELECT * FROM katalog where id_kategoria='watch'"; //создаем запрос на выборку данных
    $r=mysqli_query($a, $q) or die('error:'.mysqli_error()); //выполняем запрос, сохраняя при этом результат в переменную $r
    echo ' <h2 class="color__title watch__title">APPLE WATCH</h2>
    <ul class="phone__list">';
    while($n = mysqli_fetch_array($r)){   //в цикле перебираем все записи в массиве $r, при этом каждая запись обозначена переменной $n
        //здесь в теле цикла формируем div блоки для каждой карточки: 
        // По мере необходимости вставляем полученные значения из БД, пользуясь переменными вида: $n['photo'], $n['name'] и др.
        echo 
              '<li class="phone__item watch__item">
                <img class="img__iphone" src="images/'.$n["id_img"].'" alt="apple_watch">
                <h3>'.$n["id_telefon"].'</h3>
                <p>'.$n["id_price"].'&#8381; </p>
                <button class="phone__btn" data-modal="myModal10">'.$n["id_button"].'</button>
                <div id="myModal10" class="modal">
                  <div class="modal-content">
                    <div class="modal-header">
                      <span class="close" data-modal="myModal10">&times;</span>
                    </div>
                    <div class="modal-body">
                        <div class="modal__title">Apple Watch Serias 9, 41 мм, корпус из алюминию цвета “сияющая звезда”</div><br>
                        <b>Цвет: </b> '.$n["id_color"].'<br>
                        <b>Количество памяти: </b>'.$n["id_storage"].'<br>
                        <b>Связь: </b>'.$n["id_connection"].'<br>
                        <b>Диагональ:</b>'.$n["id_diagonal"].'<br>
                        <b>Тип дисплея:</b>'.$n["id_display"].'<br>
                        <b>Основная камера:</b> '.$n["id_main_camera"].'<br>
                        <b>Фронтальная камера:</b> '.$n["id_front_camera"].'<br>
                        <b>Страна происхождения:</b> '.$n["id_country"].'<br>
                        <b>Процессор:</b> '.$n["id_processor"].'<br>
                        <b>Емкость аккумулятора:</b> '.$n["id_battery"].'<br>
                        <button class="add_korzina" href="#">Добавить</button>
                    </div>
                  </div>
                </div>
              </li>';
              '<li class="phone__item watch__item">
              <img class="img__iphone" src="images/'.$n["id_img"].'" alt="apple_watch">
              <h3>'.$n["id_telefon"].'</h3>
              <p>'.$n["id_price"].'&#8381; </p>
              <button class="phone__btn" data-modal="myModal10">'.$n["id_button"].'</button>
              <div id="myModal10" class="modal">
                <div class="modal-content">
                  <div class="modal-header">
                    <span class="close" data-modal="myModal10">&times;</span>
                  </div>
                  <div class="modal-body">
                      <div class="modal__title">Apple Watch Serias 9, 41 мм, корпус из алюминию цвета “сияющая звезда”</div><br>
                      <b>Цвет: </b> '.$n["id_color"].'<br>
                      <b>Количество памяти: </b>'.$n["id_storage"].'<br>
                      <b>Связь: </b>'.$n["id_connection"].'<br>
                      <b>Диагональ:</b>'.$n["id_diagonal"].'<br>
                      <b>Тип дисплея:</b>'.$n["id_display"].'<br>
                      <b>Основная камера:</b> '.$n["id_main_camera"].'<br>
                      <b>Фронтальная камера:</b> '.$n["id_front_camera"].'<br>
                      <b>Страна происхождения:</b> '.$n["id_country"].'<br>
                      <b>Процессор:</b> '.$n["id_processor"].'<br>
                      <b>Емкость аккумулятора:</b> '.$n["id_battery"].'<br>
                      <button class="add_korzina" href="#">Добавить</button>
                  </div>
                </div>
              </div>
            </li>';
            '<li class="phone__item watch__item">
            <img class="img__iphone" src="images/'.$n["id_img"].'" alt="apple_watch">
            <h3>'.$n["id_telefon"].'</h3>
            <p>'.$n["id_price"].'&#8381; </p>
            <button class="phone__btn" data-modal="myModal10">'.$n["id_button"].'</button>
            <div id="myModal10" class="modal">
              <div class="modal-content">
                <div class="modal-header">
                  <span class="close" data-modal="myModal10">&times;</span>
                </div>
                <div class="modal-body">
                    <div class="modal__title">Apple Watch Serias 9, 41 мм, корпус из алюминию цвета “сияющая звезда”</div><br>
                    <b>Цвет: </b> '.$n["id_color"].'<br>
                    <b>Количество памяти: </b>'.$n["id_storage"].'<br>
                    <b>Связь: </b>'.$n["id_connection"].'<br>
                    <b>Диагональ:</b>'.$n["id_diagonal"].'<br>
                    <b>Тип дисплея:</b>'.$n["id_display"].'<br>
                    <b>Основная камера:</b> '.$n["id_main_camera"].'<br>
                    <b>Фронтальная камера:</b> '.$n["id_front_camera"].'<br>
                    <b>Страна происхождения:</b> '.$n["id_country"].'<br>
                    <b>Процессор:</b> '.$n["id_processor"].'<br>
                    <b>Емкость аккумулятора:</b> '.$n["id_battery"].'<br>
                    <button class="add_korzina" href="#">Добавить</button>
                </div>
              </div>
            </div>
          </li>';
          '<li class="phone__item watch__item">
          <img class="img__iphone" src="images/'.$n["id_img"].'" alt="apple_watch">
          <h3>'.$n["id_telefon"].'</h3>
          <p>'.$n["id_price"].'&#8381; </p>
          <button class="phone__btn" data-modal="myModal10">'.$n["id_button"].'</button>
          <div id="myModal10" class="modal">
            <div class="modal-content">
              <div class="modal-header">
                <span class="close" data-modal="myModal10">&times;</span>
              </div>
              <div class="modal-body">
                  <div class="modal__title">Apple Watch Serias 9, 41 мм, корпус из алюминию цвета “сияющая звезда”</div><br>
                  <b>Цвет: </b> '.$n["id_color"].'<br>
                  <b>Количество памяти: </b>'.$n["id_storage"].'<br>
                  <b>Связь: </b>'.$n["id_connection"].'<br>
                  <b>Диагональ:</b>'.$n["id_diagonal"].'<br>
                  <b>Тип дисплея:</b>'.$n["id_display"].'<br>
                  <b>Основная камера:</b> '.$n["id_main_camera"].'<br>
                  <b>Фронтальная камера:</b> '.$n["id_front_camera"].'<br>
                  <b>Страна происхождения:</b> '.$n["id_country"].'<br>
                  <b>Процессор:</b> '.$n["id_processor"].'<br>
                  <b>Емкость аккумулятора:</b> '.$n["id_battery"].'<br>
                  <button class="add_korzina" href="#">Добавить</button>
              </div>
            </div>
          </div>
        </li>';
        '<li class="phone__item watch__item">
        <img class="img__iphone" src="images/'.$n ["id_img"].'" alt="apple_watch">
        <h3>'.$n["id_telefon"].'</h3>
        <p>'.$n["id_price"].'&#8381; </p>
        <button class="phone__btn" data-modal="myModal10">'.$n["id_button"].'</button>
        <div id="myModal10" class="modal">
          <div class="modal-content">
            <div class="modal-header">
              <span class="close" data-modal="myModal10">&times;</span>
            </div>
            <div class="modal-body">
                <div class="modal__title">Apple Watch Serias 9, 41 мм, корпус из алюминию цвета “сияющая звезда”</div><br>
                <b>Цвет: </b> '.$n["id_color"].'<br>
                <b>Количество памяти: </b>'.$n["id_storage"].'<br>
                <b>Связь: </b>'.$n["id_connection"].'<br>
                <b>Диагональ:</b>'.$n["id_diagonal"].'<br>
                <b>Тип дисплея:</b>'.$n["id_display"].'<br>
                <b>Основная камера:</b> '.$n["id_main_camera"].'<br>
                <b>Фронтальная камера:</b> '.$n["id_front_camera"].'<br>
                <b>Страна происхождения:</b> '.$n["id_country"].'<br>
                <b>Процессор:</b> '.$n["id_processor"].'<br>
                <b>Емкость аккумулятора:</b> '.$n["id_battery"].'<br>
                <button class="add_korzina" href="#">Добавить</button>
            </div>
          </div>
        </div>
      </li>';
      '<li class="phone__item watch__item">
      <img class="img__iphone" src="images/'.$n["id_img"].'" alt="apple_watch">
      <h3>'.$n["id_telefon"].'</h3>
      <p>'.$n["id_price"].'&#8381; </p>
      <button class="phone__btn" data-modal="myModal10">'.$n["id_button"].'</button>
      <div id="myModal10" class="modal">
        <div class="modal-content">
          <div class="modal-header">
            <span class="close" data-modal="myModal10">&times;</span>
          </div>
          <div class="modal-body">
              <div class="modal__title">Apple Watch Serias 9, 41 мм, корпус из алюминию цвета “сияющая звезда”</div><br>
              <b>Цвет: </b> '.$n["id_color"].'<br>
              <b>Количество памяти: </b>'.$n["id_storage"].'<br>
              <b>Связь: </b>'.$n["id_connection"].'<br>
              <b>Диагональ:</b>'.$n["id_diagonal"].'<br>
              <b>Тип дисплея:</b>'.$n["id_display"].'<br>
              <b>Основная камера:</b> '.$n["id_main_camera"].'<br>
              <b>Фронтальная камера:</b> '.$n["id_front_camera"].'<br>
              <b>Страна происхождения:</b> '.$n["id_country"].'<br>
              <b>Процессор:</b> '.$n["id_processor"].'<br>
              <b>Емкость аккумулятора:</b> '.$n["id_battery"].'<br>
              <button class="add_korzina" href="#">Добавить</button>
          </div>
        </div>
      </div>
    </li>';
    }
    echo '</div>'; //закрываем div внешнего блока  
    mysqli_close($a);  //закрываем подключение с базой
    ?>         
            </div>
        </section>
        <section class="phone__page2">
            <div class="container">
  <?php
    $a=mysqli_connect('localhost', 'root', '', 'sait') or die('connection error'); //устанавливаем подключение к БД
    $q="SELECT * FROM katalog where id_kategoria='accessoiries'"; //создаем запрос на выборку данных
    $r=mysqli_query($a, $q) or die('error:'.mysqli_error()); //выполняем запрос, сохраняя при этом результат в переменную $r
    echo '<h2 class="color__title watch__title">ACCESSOIRIES</h2>
    <ul class="phone__list">';
    while($n = mysqli_fetch_array($r)){   //в цикле перебираем все записи в массиве $r, при этом каждая запись обозначена переменной $n
        //здесь в теле цикла формируем div блоки для каждой карточки: 
        // По мере необходимости вставляем полученные значения из БД, пользуясь переменными вида: $n['photo'], $n['name'] и др.
        echo 
            '<li class="phone__item">
                <img class="img__iphone" src="images/'.$n["id_img"].'" alt="accessoirie">
                <h3>'.$n["id_telefon"].'</h3>
                <p>'.$n["id_price"].'&#8381; </p>
                <button class="phone__btn" data-modal="myModal16">'.$n["id_button"].'</button>
                <div id="myModal16" class="modal">
                  <div class="modal-content">
                    <div class="modal-header">
                      <span class="close" data-modal="myModal16">&times;</span>
                    </div>
                    <div class="modal-body">
                    <div class="modal__title">'.$n["id_telefon"].'</div><br>
                    <b>Цвет: </b> '.$n["id_color"].'<br>
                    <b>Количество памяти: </b>'.$n["id_storage"].'<br>
                    <b>Связь: </b>'.$n["id_connection"].'<br>
                    <b>Диагональ:</b>'.$n["id_diagonal"].'<br>
                    <b>Тип дисплея:</b>'.$n["id_display"].'<br>
                    <b>Основная камера:</b> '.$n["id_main_camera"].'<br>
                    <b>Фронтальная камера:</b> '.$n["id_front_camera"].'<br>
                    <b>Страна происхождения:</b> '.$n["id_country"].'<br>
                    <b>Процессор:</b> '.$n["id_processor"].'<br>
                    <b>Емкость аккумулятора:</b> '.$n["id_battery"].'<br>
                    <button class="add_korzina" href="#">Добавить</button>
                    </div>
                  </div>
                </div>
            </li>';
            '<li class="phone__item">
            <img class="img__iphone" src="images/'.$n["id_img"].'" alt="accessoirie">
            <h3>'.$n["id_telefon"].'</h3>
            <p>'.$n["id_price"].'&#8381; </p>
            <button class="phone__btn" data-modal="myModal16">'.$n["id_button"].'</button>
            <div id="myModal16" class="modal">
              <div class="modal-content">
                <div class="modal-header">
                  <span class="close" data-modal="myModal16">&times;</span>
                </div>
                <div class="modal-body">
                <div class="modal__title">'.$n["id_telefon"].'</div><br>
                <b>Цвет: </b> '.$n["id_color"].'<br>
                <b>Количество памяти: </b>'.$n["id_storage"].'<br>
                <b>Связь: </b>'.$n["id_connection"].'<br>
                <b>Диагональ:</b>'.$n["id_diagonal"].'<br>
                <b>Тип дисплея:</b>'.$n["id_display"].'<br>
                <b>Основная камера:</b> '.$n["id_main_camera"].'<br>
                <b>Фронтальная камера:</b> '.$n["id_front_camera"].'<br>
                <b>Страна происхождения:</b> '.$n["id_country"].'<br>
                <b>Процессор:</b> '.$n["id_processor"].'<br>
                <b>Емкость аккумулятора:</b> '.$n["id_battery"].'<br>
                <button class="add_korzina" href="#">Добавить</button>
                </div>
              </div>
            </div>
        </li>';
        '<li class="phone__item">
        <img class="img__iphone" src="images/'.$n["id_img"].'" alt="accessoirie">
        <h3>'.$n["id_telefon"].'</h3>
        <p>'.$n["id_price"].'&#8381; </p>
        <button class="phone__btn" data-modal="myModal16">'.$n["id_button"].'</button>
        <div id="myModal16" class="modal">
          <div class="modal-content">
            <div class="modal-header">
              <span class="close" data-modal="myModal16">&times;</span>
            </div>
            <div class="modal-body">
            <div class="modal__title">'.$n["id_telefon"].'</div><br>
            <b>Цвет: </b> '.$n["id_color"].'<br>
            <b>Количество памяти: </b>'.$n["id_storage"].'<br>
            <b>Связь: </b>'.$n["id_connection"].'<br>
            <b>Диагональ:</b>'.$n["id_diagonal"].'<br>
            <b>Тип дисплея:</b>'.$n["id_display"].'<br>
            <b>Основная камера:</b> '.$n["id_main_camera"].'<br>
            <b>Фронтальная камера:</b> '.$n["id_front_camera"].'<br>
            <b>Страна происхождения:</b> '.$n["id_country"].'<br>
            <b>Процессор:</b> '.$n["id_processor"].'<br>
            <b>Емкость аккумулятора:</b> '.$n["id_battery"].'<br>
            <button class="add_korzina" href="#">Добавить</button>
            </div>
          </div>
        </div>
          </li>';
          '<li class="phone__item">
          <img class="img__iphone" src="images/'.$n["id_img"].'" alt="accessoirie">
          <h3>'.$n["id_telefon"].'</h3>
          <p>'.$n["id_price"].'&#8381; </p>
          <button class="phone__btn" data-modal="myModal16">'.$n["id_button"].'</button>
          <div id="myModal16" class="modal">
            <div class="modal-content">
              <div class="modal-header">
                <span class="close" data-modal="myModal16">&times;</span>
              </div>
              <div class="modal-body">
              <div class="modal__title">'.$n["id_telefon"].'</div><br>
              <b>Цвет: </b> '.$n["id_color"].'<br>
              <b>Количество памяти: </b>'.$n["id_storage"].'<br>
              <b>Связь: </b>'.$n["id_connection"].'<br>
              <b>Диагональ:</b>'.$n["id_diagonal"].'<br>
              <b>Тип дисплея:</b>'.$n["id_display"].'<br>
              <b>Основная камера:</b> '.$n["id_main_camera"].'<br>
              <b>Фронтальная камера:</b> '.$n["id_front_camera"].'<br>
              <b>Страна происхождения:</b> '.$n["id_country"].'<br>
              <b>Процессор:</b> '.$n["id_processor"].'<br>
              <b>Емкость аккумулятора:</b> '.$n["id_battery"].'<br>
              <button class="add_korzina" href="#">Добавить</button>
              </div>
            </div>
          </div>
          </li>';
          '<li class="phone__item">
          <img class="img__iphone" src="images/'.$n["id_img"].'" alt="accessoirie">
          <h3>'.$n["id_telefon"].'</h3>
          <p>'.$n["id_price"].'&#8381; </p>
          <button class="phone__btn" data-modal="myModal16">'.$n["id_button"].'</button>
          <div id="myModal16" class="modal">
            <div class="modal-content">
              <div class="modal-header">
                <span class="close" data-modal="myModal16">&times;</span>
              </div>
              <div class="modal-body">
              <div class="modal__title">'.$n["id_telefon"].'</div><br>
              <b>Цвет: </b> '.$n["id_color"].'<br>
              <b>Количество памяти: </b>'.$n["id_storage"].'<br>
              <b>Связь: </b>'.$n["id_connection"].'<br>
              <b>Диагональ:</b>'.$n["id_diagonal"].'<br>
              <b>Тип дисплея:</b>'.$n["id_display"].'<br>
              <b>Основная камера:</b> '.$n["id_main_camera"].'<br>
              <b>Фронтальная камера:</b> '.$n["id_front_camera"].'<br>
              <b>Страна происхождения:</b> '.$n["id_country"].'<br>
              <b>Процессор:</b> '.$n["id_processor"].'<br>
              <b>Емкость аккумулятора:</b> '.$n["id_battery"].'<br>
              <button class="add_korzina" href="#">Добавить</button>
              </div>
            </div>
          </div>
          </li>';
          '<li class="phone__item">
          <img class="img__iphone" src="images/'.$n["id_img"].'" alt="accessoirie">
          <h3>'.$n["id_telefon"].'</h3>
          <p>'.$n["id_price"].'&#8381; </p>
          <button class="phone__btn" data-modal="myModal16">'.$n["id_button"].'</button>
          <div id="myModal16" class="modal">
            <div class="modal-content">
              <div class="modal-header">
                <span class="close" data-modal="myModal16">&times;</span>
              </div>
              <div class="modal-body">
              <div class="modal__title">'.$n["id_telefon"].'</div><br>
              <b>Цвет: </b> '.$n["id_color"].'<br>
              <b>Количество памяти: </b>'.$n["id_storage"].'<br>
              <b>Связь: </b>'.$n["id_connection"].'<br>
              <b>Диагональ:</b>'.$n["id_diagonal"].'<br>
              <b>Тип дисплея:</b>'.$n["id_display"].'<br>
              <b>Основная камера:</b> '.$n["id_main_camera"].'<br>
              <b>Фронтальная камера:</b> '.$n["id_front_camera"].'<br>
              <b>Страна происхождения:</b> '.$n["id_country"].'<br>
              <b>Процессор:</b> '.$n["id_processor"].'<br>
              <b>Емкость аккумулятора:</b> '.$n["id_battery"].'<br>
              <button class="add_korzina" href="#">Добавить</button>
              </div>
            </div>
          </div>
          </li>';
          '<li class="phone__item">
          <img class="img__iphone" src="images/'.$n["id_img"].'" alt="accessoirie">
          <h3>'.$n["id_telefon"].'</h3>
          <p>'.$n["id_price"].'&#8381; </p>
          <button class="phone__btn" data-modal="myModal16">'.$n["id_button"].'</button>
          <div id="myModal16" class="modal">
            <div class="modal-content">
              <div class="modal-header">
                <span class="close" data-modal="myModal16">&times;</span>
              </div>
              <div class="modal-body">
              <div class="modal__title">'.$n["id_telefon"].'</div><br>
              <b>Цвет: </b> '.$n["id_color"].'<br>
              <b>Количество памяти: </b>'.$n["id_storage"].'<br>
              <b>Связь: </b>'.$n["id_connection"].'<br>
              <b>Диагональ:</b>'.$n["id_diagonal"].'<br>
              <b>Тип дисплея:</b>'.$n["id_display"].'<br>
              <b>Основная камера:</b> '.$n["id_main_camera"].'<br>
              <b>Фронтальная камера:</b> '.$n["id_front_camera"].'<br>
              <b>Страна происхождения:</b> '.$n["id_country"].'<br>
              <b>Процессор:</b> '.$n["id_processor"].'<br>
              <b>Емкость аккумулятора:</b> '.$n["id_battery"].'<br>
              <button class="add_korzina" href="#">Добавить</button>
              </div>
            </div>
          </div>
          </li>';
          '<li class="phone__item">
          <img class="img__iphone" src="images/'.$n["id_img"].'" alt="accessoirie">
          <h3>'.$n["id_telefon"].'</h3>
          <p>'.$n["id_price"].'&#8381; </p>
          <button class="phone__btn" data-modal="myModal16">'.$n["id_button"].'</button>
          <div id="myModal16" class="modal">
            <div class="modal-content">
              <div class="modal-header">
                <span class="close" data-modal="myModal16">&times;</span>
              </div>
              <div class="modal-body">
              <div class="modal__title">'.$n["id_telefon"].'</div><br>
              <b>Цвет: </b> '.$n["id_color"].'<br>
              <b>Количество памяти: </b>'.$n["id_storage"].'<br>
              <b>Связь: </b>'.$n["id_connection"].'<br>
              <b>Диагональ:</b>'.$n["id_diagonal"].'<br>
              <b>Тип дисплея:</b>'.$n["id_display"].'<br>
              <b>Основная камера:</b> '.$n["id_main_camera"].'<br>
              <b>Фронтальная камера:</b> '.$n["id_front_camera"].'<br>
              <b>Страна происхождения:</b> '.$n["id_country"].'<br>
              <b>Процессор:</b> '.$n["id_processor"].'<br>
              <b>Емкость аккумулятора:</b> '.$n["id_battery"].'<br>
              <button class="add_korzina" href="#">Добавить</button>
              </div>
            </div>
          </div>
          </li>';
          '<li class="phone__item">
          <img class="img__iphone" src="images/'.$n["id_img"].'" alt="accessoirie">
          <h3>'.$n["id_telefon"].'</h3>
          <p>'.$n["id_price"].'&#8381; </p>
          <button class="phone__btn" data-modal="myModal16">'.$n["id_button"].'</button>
          <div id="myModal16" class="modal">
            <div class="modal-content">
              <div class="modal-header">
                <span class="close" data-modal="myModal16">&times;</span>
              </div>
              <div class="modal-body">
              <div class="modal__title">'.$n["id_telefon"].'</div><br>
              <b>Цвет: </b> '.$n["id_color"].'<br>
              <b>Количество памяти: </b>'.$n["id_storage"].'<br>
              <b>Связь: </b>'.$n["id_connection"].'<br>
              <b>Диагональ:</b>'.$n["id_diagonal"].'<br>
              <b>Тип дисплея:</b>'.$n["id_display"].'<br>
              <b>Основная камера:</b> '.$n["id_main_camera"].'<br>
              <b>Фронтальная камера:</b> '.$n["id_front_camera"].'<br>
              <b>Страна происхождения:</b> '.$n["id_country"].'<br>
              <b>Процессор:</b> '.$n["id_processor"].'<br>
              <b>Емкость аккумулятора:</b> '.$n["id_battery"].'<br>
              <button class="add_korzina" href="#">Добавить</button>
              </div>
            </div>
          </div>
          </li>';
}
echo '</div>'; //закрываем div внешнего блока  
mysqli_close($a);  //закрываем подключение с базой
?>       
            </div>
        </section>
        <section class="contacts">
          <div class="container">
              <div class="contacts__inner">
                  <form class="contacts__form" action="#">
                      <h2 class="contacts__title">ХОЧЕШЬ IPHONE 15 PRO?</h2>
                      <input class="contacts__input" type="text" placeholder="Ваше имя">
                      <input class="contacts__input" type="tel" placeholder="Номер телефона">
                      <p>В ближайшее время наш менеджер свяжется с Вами</p>
                      <button type="submit">ЗАКАЗАТЬ</button>
                  </form>
                  <img class="contacts__img" src="images/contact.jpg" alt="iphone">
              </div>
          </div>
      </section>
    </main>
    <footer class="footer">
        <div class="container">
            <div class="footer__inner">
                <a class="footer__link" href="#">Политика конфиденциальности</a>
                <a href="index.html" class="logo">
                    <img src="images/logo.svg" alt="лого" height="80" class="logo__img">
                </a>
                <a href="tel:+7 913 813 63-29" class="phone">+7 913-813-63-29</a>   
            </div>
        </div>
    </footer>
</body>
</html>