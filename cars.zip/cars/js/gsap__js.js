//gsap
const tl = gsap.timeline({ defaults: {duration: 1.4} })
tl.from(".title",{ opacity: 0, y: 30}, 0.4)
  .from(".headline__img",{opacity: 0,  x: -30}, 1)
  .from(".header",{opacity: 0,  y: -30}, 1)


  
//scroll
  
  gsap.from(".headline__btn", {
    scrollTrigger: {
      trigger: ".title",
      start: "center center",
      scrub: true,
    },
    yPercent: -30,
    opacity: 0,
  })

  gsap.from(".new", {
    scrollTrigger: {
      trigger: ".headline__btn",
      start: "top bottom",
      scrub: true,
    },
    scale: 0,
    yPercent: -50,
    opacity: 0,
  })
  gsap.from(".color__title", {
    scrollTrigger: {
      trigger: ".images__new",
      start: "top top",
      scrub: true,
    },
    yPercent: -20,
    opacity: 0,
  })
  gsap.from(".color__item", {
    scrollTrigger: {
      trigger: ".new__info",
      start: "top top",
      scrub: true,
    },
    scale: 0,
    xPercent: -50,
  })
  gsap.from(".map", {
    scrollTrigger: {
      trigger: ".join-text",
      start: "top top",
      scrub: true,
    },
    scale: 0,
    transformOrigin: "top center",
    stagger: 0.1,
  });
