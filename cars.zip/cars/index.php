<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?
    family=Bebas+Neue&family=Inter:wght@400;700&display=swap" 
    rel="stylesheet">
    <link type="image/x-icon" rel="shortcut icon" href="images/ico.ico">
    <link rel="stylesheet" href="css/normalize.css">
    <link rel="stylesheet" href="css/style.css">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/gsap/3.12.3/gsap.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/gsap/3.12.3/ScrollTrigger.min.js"></script>
    <script src="js/gsap__js.js" defer></script>
    <script src="js/menu.js" defer></script>

    <title>Apple</title>
</head>
<body>
    <header class="header">
        <div class="container">
            <div class="dropdown"> 
                <div class="dropdown_between"> 
                    <a href="index.html" class="logo">
                        <img src="images/logo.svg" alt="лого" height="80" class="logo__img">
                    </a>
                </div> 
                <div class="dropdown_between"> 
                    <a href="#" class="korzina">
                        <img src="images/korzina.png" alt="поиск" class="korzina__img">
                    </a> 
                </div> 
                <div class="dropdown_between"> 
                    <button class="dropbtn">Меню</button> 
                    <div class="dropdown-content"> 
                      <a href="index6.html" class="border_nav">Вход</a> 
                      <a href="index2.php" class="border_nav">Каталог</a> 
                      <a href="index5.html" class="border_nav">Корзина</a>    
                    </div> 
                </div>
            </div>
            <nav class="nav">
                <ul class="menu">
                    <li class="menu__item">
                        <a class="menu__link" href="index6.html">Личный кабинет</a>
                    </li>
                    <li class="menu__item">
                        <a class="menu__link" href="index2.php">Каталог</a>
                    </li>
                    <li class="menu__item">
                        <a class="menu__link" href="index5.html">Корзина</a>
                    </li>
                </ul>
                <a href="index.html" class="logo">
                    <img src="images/logo.svg" alt="лого" height="80" class="logo__img">
                </a>
                <a href="tel:+7 913 813 6329" class="phone">+7 913-813-63-29</a>
            </nav>
        </div>
    </header>
    <main class="main">
        <section class="headline">
            <div class="container">
                <h1 class="title">НОВЫЙ IPHONE 15 PRO</h1>
                <img class="headline__img" src="images/iphone.png" alt="IPHONE 15 PRO">
                <a class="headline__btn" href="index2.html">ВЫБРАТЬ</a>                      
            </div> 
        </section>
        <section class="new">
            <div class="container">
                <h2 class="new__title">ЧТО НОВОГО</h2>
                <div class="new__info">
                    <div class="new__text">
                        <p>
                            Все модели оснащены однокристальной системой 
                            A16 Bionic, 48-мегапиксельной основной камерой и 
                            экранами ProMotion с защитой Ceramic Shield и частотным
                            диапазоном 1 — 120 Гц, а также ускоренной памятью LPDDR5. 
                            Дизайн линейки обновлен, на фронтальной панели смартфонов 
                            два выреза. 
                        </p>
                        <p>
                            Все iPhone 15 в США будут продаваться без лотка для 
                            SIM-карт: производитель заявляет, что улучшенная технология
                            eSIM позволит перенести старые электронные сим-карты на 
                            новые смартфоны
                        </p>
                        <b>
                            iPhone 15 Pro вышел в новом дизайне — без фирменной 
                            «челки». Также в ассортименте появился новый цвет. 
                            В смартфоне, в отличие от «обычных» 15-х айфонов, 
                            установлен процессор A16 Bionic, который может за 
                            секунду производить 4 трлн операций с фото.
                        </b>
                    </div>
                    <img class="images__new" src="images/iphone_news.jpg" alt="iphone">
                </div>
            </div>
        </section>
        <section class="color">
            <div class="container">
                <h2 class="color__title">ВЫБЕРИТЕ СВОЙ ЦВЕТ</h2>
                <ul class="color__list">
                    <li class="color__item">
                        <img src="images/color-1.jpg" alt="">
                        <h3>Silver</h3>
                        <p>Серебристый</p>
                    </li>
                    <li class="color__item">
                        <img src="images/color-2.jpg" alt="">
                        <h3>Deep purple</h3>
                        <p>Темно-фиолетовый</p>
                    </li>
                    <li class="color__item">
                        <img src="images/color-3.jpg" alt="">
                        <h3>Gold</h3>
                        <p>Золотой</p>
                    </li>
                    <li class="color__item">
                        <img src="images/color-4.jpg" alt="">
                        <h3>Space Black</h3>
                        <p>Космический черный</p>
                    </li>
                </ul>
            </div>
        </section>
        <section class="map">
            <div class="container">
                <div class="phone__inner">
                    <div class="care_block square">
                        <h1 class="map__title">
                            Контакты
                        </h1>
                        <h4 class="map__title1">
                            Адрес
                        </h4>
                        <p class="map__text">
                            Барнаул, пр.Строителей 119а<br>
                            Павловловский тракт, 251В
                        </p>
                        <h4 class="map__title1">
                            Телефон
                        </h4>
                        <p class="map__text">
                            +7 913-813-63-29
                        </p>
                        <h4 class="map-subtitle">
                            E-mail
                        </h4>
                        <p class="map__text">
                            apple.com
                        </p>
                    </div>
                    <div class="phone_block mapkarta11">
                        <iframe src="https://yandex.ru/map-widget/v1/?um=constructor%3A5631c1b6fc00feb25c8ad1ac3303d88161aaa2b29ad2d0b7b5017fc49bb31090&amp;source=constructor" width="580" height="550" frameborder="0"></iframe>
                    </div>
                    <div class="care_block mapkarta22">
                        <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d9528.42946453839!2d83.75195450927151!3d53.34133423176587!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x42dda468c4ce9629%3A0x69fa49aea5ce461d!2z0JPQsNC70LDQutGC0LjQutCw!5e0!3m2!1sru!2sru!4v1700550505708!5m2!1sru!2sru" width="319" height="250" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
                    </div>
                </div>
            </div>
        </section>
        <section class="contacts">
            <div class="container">
                <div class="contacts__inner">
                    <form class="contacts__form" action="#">
                        <h2 class="contacts__title">ХОЧЕШЬ IPHONE 15 PRO?</h2>
                        <input class="contacts__input" type="text" placeholder="Ваше имя">
                        <input class="contacts__input" type="tel" placeholder="Номер телефона">
                        <p>В ближайшее время наш менеджер свяжется с Вами</p>
                        <button type="submit">ЗАКАЗАТЬ</button>
                    </form>
                    <img class="contacts__img" src="images/contact.jpg" alt="iphone">
                </div>
            </div>
        </section>
    </main>
    <footer class="footer">
        <div class="container">
            <div class="footer__inner">
                <a class="footer__link" href="https://www.apple.com/ru/legal/privacy/ru/">Политика конфиденциальности</a>
                <a href="index.html" class="logo">
                    <img src="images/logo.svg" alt="лого" height="80" class="logo__img">
                </a>
                <a href="tel:+7 913 813 63-29" class="footer__phone">+7 913-813-63-29</a>   
            </div>
        </div>
    </footer> 
</body>
</html>